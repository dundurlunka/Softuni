﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.GenericBox
{
    class Program
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var list = new List<Box<string>>();
            for (int i = 0; i < n; i++)
            {
                var value = Console.ReadLine();
                Box<string> box = new Box<string>(value);
                //Box<int> box = new Box<int>(int.Parse(value));
                list.Add(box);
            }
            var indeces = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            list = Swapper.Swap(list, indeces);
            foreach (var el in list)
            {
                Console.WriteLine(el.ToString());
            }
            
        }
    }
}
