﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07.FoodShortage
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
