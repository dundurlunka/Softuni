﻿using System;

public interface IDrawable
{
    void Draw();
}

